library(haven)
library(dplyr)


# save project 19379 data
pr_no <- "CA19379"
client_name <- "Theravance"
data_path <- paste("Y:/production", client_name,  pr_no, "sas_prg/sas_data/", sep = "/")
setwd(data_path)

dm <- read_sas("dm.sas7bdat")
ex <- read_sas("ex.sas7bdat") %>% filter(EX_TRT_C != "07_G")
vs <- read_sas("vs.sas7bdat")
ae <- read_sas("ae.sas7bdat")
eg <- read_sas("eg.sas7bdat")
lb_cq <- read_sas("lb_cq.sas7bdat") %>% filter( trimws(PERIOD) != "2" & trimws(PERIOD) != "Early Termination <7")
# lb_cq <- read_sas("lb_cq.sas7bdat")
cm <- read_sas("cm.sas7bdat")
cr <- read_sas("cr.sas7bdat")
ds <- read_sas("ds.sas7bdat")

pr_no = ""
setwd("C:/Users/zhuob01/Documents/Examples/QCdata/data")
save(dm, file = paste(pr_no, "dm19379.RData", sep = ""))
save(ex, file = paste(pr_no, "ex.RData", sep = ""))
save(vs, file = paste(pr_no, "vs.RData", sep = ""))
save(ae, file = paste(pr_no, "ae.RData", sep = ""))
save(eg, file = paste(pr_no, "eg.RData", sep = ""))
save(lb_cq, file = paste(pr_no, "lb_cq.RData", sep = ""))
save(cm, file = paste(pr_no, "cm.RData", sep = ""))
save(cr, file = paste(pr_no, "cr.RData", sep = ""))
save(ds, file = paste(pr_no, "ds.RData", sep = ""))



# save project 20151 data
pr_no <- "CA20151"
client_name <- "Lupin"
data_path <- paste("Y:/production", client_name,  pr_no, "sas_prg/sas_data/", sep = "/")
setwd(data_path)

dm <- read_sas("dm.sas7bdat")
ex <- read_sas("ex.sas7bdat")
vs <- read_sas("vs.sas7bdat")
ae <- read_sas("ae.sas7bdat")
eg <- read_sas("eg.sas7bdat")
lb_cq <- read_sas("lb_cq.sas7bdat")
cm <- read_sas("cm.sas7bdat")
cr <- read_sas("cr.sas7bdat")
ds <- read_sas("ds.sas7bdat")


setwd("C:/Users/zhuob01/Documents/Examples/QCdata/data")
save(dm, file = paste(pr_no, "_dm.RData", sep = ""))
save(ex, file = paste(pr_no, "_ex.RData", sep = ""))
save(vs, file = paste(pr_no, "_vs.RData", sep = ""))
save(ae, file = paste(pr_no, "_ae.RData", sep = ""))
save(eg, file = paste(pr_no, "_eg.RData", sep = ""))
save(lb_cq, file = paste(pr_no, "_lb_cq.RData", sep = ""))
save(cm, file = paste(pr_no, "_cm.RData", sep = ""))
save(cr, file = paste(pr_no, "_cr.RData", sep = ""))
save(ds, file = paste(pr_no, "_ds.RData", sep = ""))


