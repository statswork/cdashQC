
#' the data set dm from CA19379.
#'
#'
#'
#' @format the data set
#'
#'

"dm"


#' the data set ex from CA19379.
#'
#'
#'
#' @format the data set
#'
#'

"ex"

#' the data set ae from CA19379.
#'
#'
#'
#' @format the data set
#'
#'

"ae"




#' the data set cm from CA19379.
#'
#'
#'
#' @format the data set
#'
#'

"cm"



#' the data set ds from CA19379.
#'
#'
#'
#' @format the data set
#'
#'

"ds"



#' the data set eg from CA19379.
#'
#'
#'
#' @format the data set
#'
#'

"eg"



#' the data set vsfrom CA19379.
#'
#'
#'
#' @format the data set
#'
#'

"vs"

